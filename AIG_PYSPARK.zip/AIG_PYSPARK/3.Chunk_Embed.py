"""
Chunking & Embedding using PySpark + OpenAI

"""

import sys, re, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import (
    RAW_DIR, CHUNKS_DIR, EMBEDDINGS_DIR,
    COMPANY_NAME, FISCAL_YEAR, CHUNK_SIZE, CHUNK_OVERLAP,
    EMBEDDING_BACKEND, LOCAL_EMBED_MODEL,
    OPENAI_EMBED_MODEL, OPENAI_API_KEY,
    SPARK_APP_NAME, SPARK_MASTER,
)

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from pyspark.sql import functions as F
import pandas as pd
import numpy as np


# Chunking(runs inside PySpark partitions)
def chunk_partition(rows):
    """Generator that yields chunks from each filing in the partition.
    Designed to handle multiple filings per partition for scalability."""
    for row in rows:
        company, year, raw_text = row[0], row[1], row[2]

        #cleaning text
        text = re.sub(r'\s+', ' ', raw_text).strip()

        chunk_id, start = 0, 0
        while start < len(text):
            end = min(start + CHUNK_SIZE, len(text))
            chunk_text = text[start:end].strip()
            if len(chunk_text) > 50:
                yield (
                    f"{company}_{year}_{chunk_id}",
                    company,
                    int(year),
                    chunk_id,
                    int(start // 3000) + 1,
                    chunk_text,
                )
                chunk_id += 1
            start += CHUNK_SIZE - CHUNK_OVERLAP


# Embedding(runs on driver)
def embed_on_driver(texts):
    if EMBEDDING_BACKEND == "openai":
        import openai, time
        client = openai.OpenAI(api_key=OPENAI_API_KEY)
        all_vecs = []
        for i in range(0, len(texts), 256):
            batch = texts[i:i+256]
            print(f"    Embedding {i}–{i+len(batch)} of {len(texts)} ...", flush=True)
            resp = client.embeddings.create(input=batch, model=OPENAI_EMBED_MODEL)
            all_vecs.extend([r.embedding for r in resp.data])
            time.sleep(1)
        return np.array(all_vecs, dtype=np.float32)
    else:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(LOCAL_EMBED_MODEL)
        return model.encode(texts, batch_size=64, show_progress_bar=True)


#Main Function
def run(spark=None):
    print(f"\n{'='*60}")
    print(f" Chunking & Embedding (PySpark)")
    print(f" Chunk: {CHUNK_SIZE} | Overlap: {CHUNK_OVERLAP}")
    print(f" Embedding: {EMBEDDING_BACKEND}")
    print(f"{'='*60}\n")

    #Loading raw filing
    path = RAW_DIR / f"{COMPANY_NAME}_{FISCAL_YEAR}.txt"
    if not path.exists():
        sys.exit(f"  {path.name} not found. Run Step 1 first.")
    text = path.read_text(encoding="utf-8", errors="replace")
    print(f"  Loaded {path.name} ({len(text):,} chars)")

    #SparkSession
    if spark is None:
        spark = (SparkSession.builder
                 .appName(SPARK_APP_NAME).master(SPARK_MASTER)
                 .config("spark.driver.memory", "4g").getOrCreate())
        spark.sparkContext.setLogLevel("WARN")

    
    # PYSPARK: Distributed Chunking via mapPartitions
    # Create RDD - for multiple filings, parallelize list of all filings
    raw_rdd = spark.sparkContext.parallelize([(COMPANY_NAME, FISCAL_YEAR, text)], 1)
    chunk_rdd = raw_rdd.mapPartitions(chunk_partition)

    schema = StructType([
        StructField("uid",      StringType(),  False),
        StructField("company",  StringType(),  False),
        StructField("year",     IntegerType(), False),
        StructField("chunk_id", IntegerType(), False),
        StructField("page_est", IntegerType(), False),
        StructField("text",     StringType(),  False),
    ])

    #Creating Spark DataFrame from RDD
    df_chunks = spark.createDataFrame(chunk_rdd, schema=schema)

    # Adding text_length column using Spark's built-in length function
    df_chunks = df_chunks.withColumn("text_length", F.length(F.col("text")))

    # Filtering out very short chunks using Spark DataFrame filter
    df_chunks = df_chunks.filter(F.col("text_length") >= 50)

    # Adding a flag for chunks that likely contain financial tables
    df_chunks = df_chunks.withColumn(
        "has_financial_data",
        F.when(
            F.lower(F.col("text")).contains("net premiums written") |
            F.lower(F.col("text")).contains("underwriting income") |
            F.lower(F.col("text")).contains("loss ratio"),
            F.lit(True)
        ).otherwise(F.lit(False))
    )

    # Caching for multiple operations
    df_chunks.cache()

    total_chunks = df_chunks.count()
    print(f"  Total chunks: {total_chunks:,}")
 
    # PYSPARK: Spark SQL Analysis — chunk distribution
    df_chunks.createOrReplaceTempView("chunks")

    # Chunk distribution per estimated page
    print("\n Spark SQL: Chunk Distribution by Page (sample):")
    spark.sql("""
        SELECT page_est, 
               COUNT(*) as num_chunks,
               ROUND(AVG(text_length)) as avg_length,
               MIN(text_length) as min_length,
               MAX(text_length) as max_length
        FROM chunks
        GROUP BY page_est
        ORDER BY page_est
        LIMIT 10
    """).show(truncate=False)

    #Aggregations — summary statistics

    print(" Spark Aggregation: Overall chunk statistics:")
    df_chunks.agg(
        F.count("uid").alias("total_chunks"),
        F.round(F.avg("text_length")).alias("avg_text_length"),
        F.min("text_length").alias("min_text_length"),
        F.max("text_length").alias("max_text_length"),
        F.countDistinct("page_est").alias("unique_pages"),
    ).show(truncate=False)

    # Counting chunks with financial data
    print("  Spark Aggregation: Chunks with financial data:")
    df_chunks.groupBy("has_financial_data").agg(
        F.count("uid").alias("chunk_count"),
        F.round(F.avg("text_length")).alias("avg_length"),
    ).show(truncate=False)

  
    #Top pages by chunk density
    print("  Spark SQL: Pages with most financial content:")
    spark.sql("""
        SELECT page_est,
               COUNT(*) as chunk_count,
               SUM(CASE WHEN has_financial_data THEN 1 ELSE 0 END) as financial_chunks,
               ROUND(AVG(text_length)) as avg_length
        FROM chunks
        GROUP BY page_est
        HAVING SUM(CASE WHEN has_financial_data THEN 1 ELSE 0 END) > 0
        ORDER BY financial_chunks DESC
        LIMIT 10
    """).show(truncate=False)

    # Saving chunks(dropping helper columns for clean output)
    pdf_chunks = df_chunks.select("uid", "company", "year", "chunk_id", "page_est", "text").toPandas()
    chunks_path = CHUNKS_DIR / "chunks.csv"
    pdf_chunks.to_csv(chunks_path, index=False)
    print(f"  Chunks saved -> {chunks_path}")

  
    # EMBEDDING: Runs on driver
    print(f"\n  Embedding {len(pdf_chunks):,} chunks ...")
    vectors = embed_on_driver(pdf_chunks["text"].tolist())

    # Saving embeddings
    embed_path = EMBEDDINGS_DIR / "embeddings.csv"
    pdf_embed = pd.DataFrame({
        "uid": pdf_chunks["uid"].tolist(),
        "embedding_json": [json.dumps([round(float(x), 6) for x in v]) for v in vectors],
    })
    pdf_embed.to_csv(embed_path, index=False)
    print(f"  Embeddings saved to {embed_path}")

    #Uncache
    df_chunks.unpersist()

    print(f"\nDone. Spark session kept alive for downstream steps.\n")
    return spark

if __name__ == "__main__":
    spark = run()
    if spark:
        spark.stop()