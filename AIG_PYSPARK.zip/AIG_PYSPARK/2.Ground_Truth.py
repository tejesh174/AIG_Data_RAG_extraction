"""
Building the ground truth dataset using PySpark.
5 observations per variable (15 total)
All values verified from: https://www.sec.gov/Archives/edgar/data/5272/000000527226000023/aig-20251231.htm

"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import (
    GROUND_TRUTH_PATH, COMPANY_NAME, FISCAL_YEAR, VARIABLES,
    SPARK_APP_NAME, SPARK_MASTER,
)

from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, FloatType,
)
from pyspark.sql import functions as F

GROUND_TRUTH_RECORDS = [
    # Net Premiums Written (5 observations)
    {"obs_id": "NPW_NAC_2025", "variable": "net_premiums_written",
     "segment": "North America Commercial", "year": 2025,
     "ground_truth": "8759", "unit": "millions USD",
     "source_section": "MD&A - North America Commercial Segment Operations"},

    {"obs_id": "NPW_IC_2025", "variable": "net_premiums_written",
     "segment": "International Commercial", "year": 2025,
     "ground_truth": "8663", "unit": "millions USD",
     "source_section": "MD&A - International Commercial Segment Operations"},

    {"obs_id": "NPW_GP_2025", "variable": "net_premiums_written",
     "segment": "Global Personal", "year": 2025,
     "ground_truth": "6253", "unit": "millions USD",
     "source_section": "MD&A - Global Personal Segment Operations"},

    {"obs_id": "NPW_NAC_2024", "variable": "net_premiums_written",
     "segment": "North America Commercial", "year": 2024,
     "ground_truth": "8452", "unit": "millions USD",
     "source_section": "MD&A - North America Commercial Segment Operations"},

    {"obs_id": "NPW_IC_2024", "variable": "net_premiums_written",
     "segment": "International Commercial", "year": 2024,
     "ground_truth": "8364", "unit": "millions USD",
     "source_section": "MD&A - International Commercial Segment Operations"},

    # Underwriting Income (5 observations)
    {"obs_id": "UW_NAC_2025", "variable": "underwriting_income",
     "segment": "North America Commercial", "year": 2025,
     "ground_truth": "1144", "unit": "millions USD",
     "source_section": "MD&A - North America Commercial Segment Operations"},

    {"obs_id": "UW_IC_2025", "variable": "underwriting_income",
     "segment": "International Commercial", "year": 2025,
     "ground_truth": "1118", "unit": "millions USD",
     "source_section": "MD&A - International Commercial Segment Operations"},

    {"obs_id": "UW_GP_2025", "variable": "underwriting_income",
     "segment": "Global Personal", "year": 2025,
     "ground_truth": "70", "unit": "millions USD",
     "source_section": "MD&A - Global Personal Segment Operations"},

    {"obs_id": "UW_NAC_2024", "variable": "underwriting_income",
     "segment": "North America Commercial", "year": 2024,
     "ground_truth": "548", "unit": "millions USD",
     "source_section": "MD&A - North America Commercial Segment Operations"},

    {"obs_id": "UW_IC_2024", "variable": "underwriting_income",
     "segment": "International Commercial", "year": 2024,
     "ground_truth": "1227", "unit": "millions USD",
     "source_section": "MD&A - International Commercial Segment Operations"},

    # Regulatory Jurisdiction (5 observations)
    {"obs_id": "REG_US", "variable": "regulatory_jurisdiction",
     "segment": "United States", "year": 2025,
     "ground_truth": "NYDFS", "unit": None,
     "source_section": "Item 1 Business - Regulation - United States - States"},

    {"obs_id": "REG_UK", "variable": "regulatory_jurisdiction",
     "segment": "United Kingdom", "year": 2025,
     "ground_truth": "PRA", "unit": None,
     "source_section": "Item 1 Business - Regulation - International"},

    {"obs_id": "REG_EU", "variable": "regulatory_jurisdiction",
     "segment": "European Union (Luxembourg)", "year": 2025,
     "ground_truth": "Commissariat aux Assurances", "unit": None,
     "source_section": "Item 1 Business - Regulation - International"},

    {"obs_id": "REG_SINGAPORE", "variable": "regulatory_jurisdiction",
     "segment": "Singapore", "year": 2025,
     "ground_truth": "MAS", "unit": None,
     "source_section": "Item 1 Business - Regulation - International"},

    {"obs_id": "REG_JAPAN", "variable": "regulatory_jurisdiction",
     "segment": "Japan", "year": 2025,
     "ground_truth": "JFSA", "unit": None,
     "source_section": "Item 1 Business - Regulation - International"},
]

#Build and validate ground truth dataset using PySpark.
def build_ground_truth(spark):
    print(f"\n{'='*60}")
    print(f" Building Ground Truth Dataset (PySpark)")
    print(f" Company: {COMPANY_NAME} | Filing: {FISCAL_YEAR} 10-K")
    print(f" Variables: {[v['name'] for v in VARIABLES]}")
    print(f"{'='*60}\n")

    # Creating Spark DataFrame from records
    schema = StructType([
        StructField("obs_id",         StringType(),  False),
        StructField("variable",       StringType(),  False),
        StructField("segment",        StringType(),  False),
        StructField("year",           IntegerType(), False),
        StructField("ground_truth",   StringType(),  True),
        StructField("unit",           StringType(),  True),
        StructField("source_section", StringType(),  True),
    ])

    rows = []
    for rec in GROUND_TRUTH_RECORDS:
        rows.append((
            rec["obs_id"], rec["variable"], rec["segment"],
            rec["year"], str(rec["ground_truth"]) if rec["ground_truth"] is not None else None,
            rec["unit"], rec["source_section"],
        ))

    df_gt = spark.createDataFrame(rows, schema=schema)

    #Adding company column
    df_gt = df_gt.withColumn("company", F.lit(COMPANY_NAME))

    # Reordering columns
    df_gt = df_gt.select(
        "company", "obs_id", "variable", "segment", "year",
        "ground_truth", "unit", "source_section"
    )

    # Registering as temp view for Spark SQL validation
    df_gt.createOrReplaceTempView("ground_truth")

    #Validating observation counts per variable
    print("  Spark SQL Validation - Observations per variable:")
    spark.sql("""
        SELECT variable, COUNT(*) as obs_count, 
               COUNT(ground_truth) as non_null_count
        FROM ground_truth
        GROUP BY variable
        ORDER BY variable
    """).show(truncate=False)

    #Checking for null ground truth values
    null_check = spark.sql("""
        SELECT COUNT(*) as null_count
        FROM ground_truth
        WHERE ground_truth IS NULL
    """).collect()[0]["null_count"]
    print(f"  Null ground truth values: {null_check}")

    #Summary of unique segments per variable
    print("\n  Spark SQL - Segments per variable:")
    spark.sql("""
        SELECT variable, COLLECT_SET(segment) as segments
        FROM ground_truth
        GROUP BY variable
    """).show(truncate=False)

    #Year distribution
    print("  Spark SQL - Year distribution:")
    spark.sql("""
        SELECT year, COUNT(*) as count
        FROM ground_truth
        GROUP BY year
        ORDER BY year
    """).show(truncate=False)

    #saving as single CSV via Pandas for compatibility with downstream steps
    pdf_gt = df_gt.toPandas()
    pdf_gt.to_csv(GROUND_TRUTH_PATH, index=False)
    print(f"\n  Ground truth saved to {GROUND_TRUTH_PATH}")
    print(f"  Shape: {pdf_gt.shape[0]} rows x {pdf_gt.shape[1]} columns\n")
    print(pdf_gt.to_string(index=False))

    return df_gt


if __name__ == "__main__":
    spark = (SparkSession.builder
             .appName(SPARK_APP_NAME).master(SPARK_MASTER)
             .config("spark.driver.memory", "4g").getOrCreate())
    spark.sparkContext.setLogLevel("WARN")
    df_gt = build_ground_truth(spark)
    spark.stop()