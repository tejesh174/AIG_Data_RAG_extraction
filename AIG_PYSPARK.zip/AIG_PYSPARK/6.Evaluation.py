"""
Evaluation: Merging extracted values with ground truth and compute metrics.

"""

import sys, math, re
from pathlib import Path
import pandas as pd
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import (
    RESULTS_DIR, GROUND_TRUTH_PATH, VARIABLES,
    EMBEDDING_BACKEND, OPENAI_LLM_MODEL, TOP_K_CHUNKS, CHUNK_SIZE,
    SPARK_APP_NAME, SPARK_MASTER,
)

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    BooleanType, FloatType, StringType,
)
from pyspark.sql.window import Window

EXTRACTED_PATH = RESULTS_DIR / "extracted.csv"
RESULTS_PATH   = RESULTS_DIR / "results.csv"
REPORT_PATH    = RESULTS_DIR / "evaluation_report.txt"

NUMERIC_TOLERANCE = 0.02


# HELPER FUNCTIONS
def parse_number(value):
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return None
    text = str(value).strip().replace(",", "").replace("$", "")
    if not text or text.lower() in {"nan", "none", "null"}:
        return None
    if text.startswith("(") and text.endswith(")"):
        text = "-" + text[1:-1]
    try:
        return float(text)
    except ValueError:
        return None


def _numeric_match(ground_truth, extracted):
    gt = parse_number(ground_truth)
    ext = parse_number(extracted)
    if gt is None or ext is None:
        return False
    if gt == 0:
        return ext == 0
    return abs((ext - gt) / gt) <= NUMERIC_TOLERANCE


def _categorical_match(ground_truth, extracted):
    if extracted is None or (isinstance(extracted, float) and math.isnan(extracted)):
        return False
    gt = re.sub(r'[^a-z0-9]+', ' ', str(ground_truth).lower()).strip()
    ext = re.sub(r'[^a-z0-9]+', ' ', str(extracted).lower()).strip()
    if not gt or not ext:
        return False
    return gt == ext or gt in ext or ext in gt


def _is_match(var_type, ground_truth, extracted):
    if var_type == "numeric":
        return _numeric_match(ground_truth, extracted)
    return _categorical_match(ground_truth, extracted)


def _pct_error(ground_truth, extracted):
    gt = parse_number(ground_truth)
    ext = parse_number(extracted)
    if gt in {None, 0} or ext is None:
        return None
    return round((ext - gt) / abs(gt) * 100, 2)


def _is_null(value):
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    if str(value).strip().lower() in {"", "nan", "none", "null"}:
        return True
    return False


# Main Function
def run(spark=None):
    print(f"\n{'='*60}")
    print(f"  Step 6: Evaluation (PySpark)")
    print(f"{'='*60}\n")

    #SparkSession
    if spark is None:
        spark = (SparkSession.builder
                 .appName(SPARK_APP_NAME).master(SPARK_MASTER)
                 .config("spark.driver.memory", "4g").getOrCreate())
        spark.sparkContext.setLogLevel("WARN")

    #Registering UDFs for match and error computation
    @F.udf(BooleanType())
    def udf_is_match(var_type, ground_truth, extracted_value):
        return _is_match(var_type, ground_truth, extracted_value)

    @F.udf(FloatType())
    def udf_pct_error(ground_truth, extracted_value):
        result = _pct_error(ground_truth, extracted_value)
        return float(result) if result is not None else None

    @F.udf(BooleanType())
    def udf_is_null(value):
        return _is_null(value)


    #Loading ground truth and extractions as Spark DataFrames
    df_gt_spark = spark.read.csv(str(GROUND_TRUTH_PATH), header=True, inferSchema=True)
    df_ext_spark = spark.read.csv(str(EXTRACTED_PATH), header=True, inferSchema=True)

    print(f"  Loaded ground truth: {df_gt_spark.count()} rows")
    print(f"  Loaded extractions: {df_ext_spark.count()} rows")

    #Joining ground truth with extractions on obs_id
    df_merged = df_gt_spark.join(
        df_ext_spark.select("obs_id", "extracted_value", "num_chunks_used"),
        on="obs_id",
        how="left"
    )
    print(f"  Merged DataFrame: {df_merged.count()} rows")


    #Building variable type lookup and add var_type column
    var_type_data = [(v["name"], v["type"]) for v in VARIABLES]
    df_var_types = spark.createDataFrame(var_type_data, ["variable", "var_type"])

    # Joining to add var_type column
    df_merged = df_merged.join(df_var_types, on="variable", how="left")


    #Applying UDFs to add match, pct_error, is_null columns
    df_eval = df_merged.withColumn(
        "match",
        udf_is_match(
            F.col("var_type"),
            F.col("ground_truth").cast("string"),
            F.col("extracted_value").cast("string")
        )
    ).withColumn(
        "pct_error",
        F.when(
            F.col("var_type") == "numeric",
            udf_pct_error(
                F.col("ground_truth").cast("string"),
                F.col("extracted_value").cast("string")
            )
        ).otherwise(F.lit(None).cast(FloatType()))
    ).withColumn(
        "is_null",
        udf_is_null(F.col("extracted_value").cast("string"))
    )

    #Caching for multiple operations
    df_eval.cache()


    #Saving results
    df_eval_pd = df_eval.toPandas()
    df_eval_pd.to_csv(RESULTS_PATH, index=False)
    print(f"\n  Results saved to {RESULTS_PATH}\n")

    #Printing results table
    print(df_eval_pd[["obs_id", "variable", "ground_truth", "extracted_value",
                       "match", "pct_error", "is_null"]].to_string(index=False))

    #Registering for SQL queries
    df_eval.createOrReplaceTempView("evaluation")

    #Spark Aggregations — Overall metrics
    print("\n  Spark Aggregation: Overall Metrics:")
    metrics_row = df_eval.agg(
        F.count("*").alias("total"),
        F.sum(F.when(F.col("match") == True, 1).otherwise(0)).alias("matches"),
        F.sum(F.when(F.col("is_null") == True, 1).otherwise(0)).alias("nulls"),
        F.sum(F.when(F.col("is_null") == False, 1).otherwise(0)).alias("non_nulls"),
        F.round(F.avg("num_chunks_used"), 1).alias("avg_chunks_used"),
    ).collect()[0]

    total = metrics_row["total"]
    matches = metrics_row["matches"]
    nulls = metrics_row["nulls"]
    non_nulls = metrics_row["non_nulls"]
    accuracy = matches / total * 100
    precision = (matches / non_nulls * 100) if non_nulls > 0 else 0
    recall = non_nulls / total * 100
    f1 = (2 * (precision * recall) / (precision + recall)) if (precision + recall) > 0 else 0
    null_rate = nulls / total * 100
 
    #Numeric only metrics (MAE, RMSE)
    print(" Numeric metrics:")
    numeric_metrics = spark.sql("""
        SELECT
            COUNT(*) as valid_extractions,
            ROUND(AVG(ABS(pct_error)), 2) as mean_abs_pct_error,
            ROUND(AVG(ABS(
                CAST(extracted_value AS DOUBLE) - CAST(ground_truth AS DOUBLE)
            )), 1) as mae,
            ROUND(SQRT(AVG(
                POWER(CAST(extracted_value AS DOUBLE) - CAST(ground_truth AS DOUBLE), 2)
            )), 1) as rmse
        FROM evaluation
        WHERE var_type = 'numeric'
          AND extracted_value IS NOT NULL
          AND CAST(extracted_value AS DOUBLE) IS NOT NULL
    """)
    numeric_metrics.show(truncate=False)
    nm_row = numeric_metrics.collect()[0]
    mae = nm_row["mae"]
    rmse = nm_row["rmse"]
    mean_pct_err = nm_row["mean_abs_pct_error"]


    #Per-variable breakdown
    print("Per-variable breakdown:")
    spark.sql("""
        SELECT variable, var_type,
               COUNT(*) as total,
               SUM(CASE WHEN match = true THEN 1 ELSE 0 END) as matches,
               ROUND(AVG(CASE WHEN match = true THEN 1.0 ELSE 0.0 END) * 100, 1) as accuracy_pct,
               SUM(CASE WHEN is_null = true THEN 1 ELSE 0 END) as null_count,
               ROUND(AVG(ABS(pct_error)), 2) as mean_abs_pct_error
        FROM evaluation
        GROUP BY variable, var_type
        ORDER BY variable
    """).show(truncate=False)

    #Window Functions — Rank by error magnitude
    print(" Observations ranked by error (worst first):")
    window_err = Window.orderBy(F.abs(F.col("pct_error")).desc())
    df_eval.filter(
        F.col("var_type") == "numeric"
    ).withColumn(
        "error_rank", F.row_number().over(window_err)
    ).select(
        "error_rank", "obs_id", "variable", "ground_truth",
        "extracted_value", "pct_error", "match"
    ).show(10, truncate=False)


    #Mismatches analysis
    print("Mismatched observations:")
    spark.sql("""
        SELECT obs_id, variable, segment, ground_truth, extracted_value, pct_error
        FROM evaluation
        WHERE match = false
        ORDER BY variable
    """).show(truncate=False)


    #BUILDING EVALUATION REPORT
    lines = []
    lines.append("=" * 62)
    lines.append("  EVALUATION REPORT")
    lines.append("=" * 62)

    lines.append(f"\n  OVERALL METRICS")
    lines.append(f"  {'Accuracy:':<25} {accuracy:.1f}%  ({matches}/{total} matches)")
    lines.append(f"  {'Precision:':<25} {precision:.1f}%  ({matches}/{non_nulls} correct of non-null)")
    lines.append(f"  {'Recall:':<25} {recall:.1f}%  ({non_nulls}/{total} non-null extractions)")
    lines.append(f"  {'F1 Score:':<25} {f1:.1f}%")
    lines.append(f"  {'Null Rate:':<25} {null_rate:.1f}%  ({nulls}/{total} returned null)")

    if mae is not None:
        valid_count = nm_row["valid_extractions"]
        lines.append(f"\n  NUMERIC METRICS (on {valid_count} valid extractions)")
        lines.append(f"  {'MAE:':<25} {mae:.1f} million USD")
        lines.append(f"  {'RMSE:':<25} {rmse:.1f} million USD")
        lines.append(f"  {'Mean |% Error|:':<25} {mean_pct_err:.2f}%")

    #Per-variable breakdown
    per_var = spark.sql("""
        SELECT variable, var_type,
               ROUND(AVG(CASE WHEN match = true THEN 1.0 ELSE 0.0 END) * 100, 0) as accuracy,
               SUM(CASE WHEN is_null = true THEN 1 ELSE 0 END) as null_count,
               COUNT(*) as total,
               ROUND(AVG(ABS(pct_error)), 2) as mean_abs_pct_error
        FROM evaluation
        GROUP BY variable, var_type
        ORDER BY variable
    """).collect()

    lines.append(f"\n  PER-VARIABLE BREAKDOWN")
    for row in per_var:
        line = f"    {row['variable']:<30} accuracy={row['accuracy']:.0f}%  nulls={row['null_count']}/{row['total']}"
        if row["var_type"] == "numeric" and row["mean_abs_pct_error"] is not None:
            line += f"  mean|%err|={row['mean_abs_pct_error']:.2f}%"
        lines.append(line)

    lines.append(f"\n  RETRIEVAL STATS")
    lines.append(f"  {'Avg chunks used:':<25} {metrics_row['avg_chunks_used']:.1f}")
    lines.append(f"  {'Numeric tolerance:':<25} {NUMERIC_TOLERANCE*100:.0f}%")
    lines.append("=" * 62)

    report = "\n".join(lines)
    print("\n" + report)

    REPORT_PATH.write_text(report)
    print(f"\n  Report saved -> {REPORT_PATH}\n")


    # Stopping Spark
    df_eval.unpersist()
    spark.stop()
    print("Spark session stopped\n")

if __name__ == "__main__":
    run()