"""
Step 5: Extracting target variables from retrieved chunks using OpenAI LLM.

"""

import sys, json, re, time
from pathlib import Path
import pandas as pd
import openai
sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import (
    RESULTS_DIR, VARIABLES, OBSERVATIONS,
    OPENAI_LLM_MODEL, OPENAI_API_KEY,
    TOP_K_CHUNKS, COMPANY_NAME, FISCAL_YEAR,
    SPARK_APP_NAME, SPARK_MASTER,
)

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, FloatType,
)

RETRIEVED_PATH = RESULTS_DIR / "retrieved_chunks.csv"
EXTRACTED_PATH = RESULTS_DIR / "extracted.csv"

SYSTEM_PROMPT = """You are a financial data extraction assistant.
Extract ONLY the specific value requested from the given SEC 10-K filing excerpts.
Rules:
- Match the EXACT fiscal year requested. Tables often show multiple years side by side (e.g., 2025, 2024, 2023). Extract ONLY from the requested year column.
- Match the EXACT segment name requested. Do not confuse values across segments.
- Distinguish between similar line items: 'Net premiums written' and 'Net premiums earned' are DIFFERENT metrics. Only extract the one requested.
- Parenthesized values like (70) mean negative: return -70.
- If the requested value is not clearly present in the excerpts, return null rather than guessing.
- Return ONLY valid JSON, no explanation."""


def extract_value(obs, variable, context):
    segment = obs.get("segment", obs.get("jurisdiction", ""))
    year = obs.get("year", FISCAL_YEAR)
    vtype = variable["type"]

    if vtype == "numeric":
        ask = (f"Extract '{variable['display']}' for {COMPANY_NAME} '{segment}' "
               f"segment, fiscal year {year}. Unit: millions USD.\n"
               f"IMPORTANT: The table may show multiple years. Extract ONLY the value from the {year} column.\n"
               f"Do NOT confuse 'net premiums written' with 'net premiums earned'.\n"
               f"Use the EXACT number from the financial table, not rounded figures from narrative text.\n"
               'Return JSON: {{"extracted_value": <number or null>}}')
    else:
        ask = (f"Extract the primary regulatory authority for {COMPANY_NAME} "
               f"operations in {segment}. Use abbreviation if exists. "
               'Return JSON: {{"extracted_value": <string or null>}}')

    client = openai.OpenAI(api_key=OPENAI_API_KEY)
    resp = client.chat.completions.create(
        model=OPENAI_LLM_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"--- EXCERPTS ---\n{context}\n--- END ---\n\n{ask}"},
        ],
        temperature=0, max_tokens=256,
        response_format={"type": "json_object"},
    )
    raw = resp.choices[0].message.content

    try:
        val = json.loads(re.sub(r"```json\s*|```", "", raw).strip()).get("extracted_value")
        if isinstance(val, str) and val.strip().lower() in {"", "null", "none"}:
            val = None
        return val, raw
    except:
        return None, raw


def run(spark=None):
    print(f"\n{'='*60}")
    print(f"  Step 5: LLM Extraction (PySpark + {OPENAI_LLM_MODEL})")
    print(f"{'='*60}\n")

    if not OPENAI_API_KEY:
        sys.exit("OPENAI_API_KEY is not set.")
    if not RETRIEVED_PATH.exists():
        sys.exit("Retrieved chunks not found. Run Step 4 first.")

    # SparkSession
    if spark is None:
        spark = (SparkSession.builder
                 .appName(SPARK_APP_NAME).master(SPARK_MASTER)
                 .config("spark.driver.memory", "4g").getOrCreate())
        spark.sparkContext.setLogLevel("WARN")

    # Loading retrieved chunks as Spark DataFrame
    df_ret_spark = spark.read.csv(str(RETRIEVED_PATH), header=True, inferSchema=True)
    print(f"  Loaded {df_ret_spark.count():,} retrieved chunks (Spark DataFrame)\n")

    # Spark SQL — Aggregate context chunks per observation
    df_ret_spark.createOrReplaceTempView("retrieved")
    print("  Spark SQL: Chunks per observation:")
    spark.sql("""
        SELECT variable, obs_id,
               COUNT(*) as chunk_count,
               ROUND(AVG(score), 4) as avg_score,
               ROUND(MAX(score), 4) as top_score
        FROM retrieved
        GROUP BY variable, obs_id
        ORDER BY variable, obs_id
    """).show(20, truncate=False)

    # Aggregating context per observation using Spark collect_list
    df_context = df_ret_spark.groupBy("variable", "obs_id").agg(
        F.count("*").alias("num_chunks_used"),
        F.collect_list(
            F.struct(
                F.col("score").cast("double").alias("score"),
                F.col("chunk_uid").alias("chunk_uid"),
                F.col("page_est").alias("page_est"),
                F.col("text").alias("text")
            )
        ).alias("chunks_collected"),
        F.round(F.avg("score"), 4).alias("avg_score"),
    )

    # Collecting aggregated contexts to driver for LLM calls
    context_rows = df_context.collect()
    print(f"  Aggregated context for {len(context_rows)} observations\n")

    # LLM EXTRACTION
    # Building lookup for variables and observations
    var_map = {v["name"]: v for v in VARIABLES}
    obs_map = {}
    for var_name, obs_list in OBSERVATIONS.items():
        for obs in obs_list:
            obs_map[obs["obs_id"]] = obs

    results = []
    total = len(context_rows)

    for count, row in enumerate(context_rows, 1):
        var_name = row["variable"]
        obs_id = row["obs_id"]
        variable = var_map[var_name]
        obs = obs_map[obs_id]
        segment = obs.get("segment", obs.get("jurisdiction", ""))
        num_chunks = row["num_chunks_used"]

        # Building context from collected chunks (sort by score descending)
        chunks_data = sorted(row["chunks_collected"], key=lambda x: -x["score"])
        context_parts = []
        for chunk in chunks_data[:TOP_K_CHUNKS]:
            context_parts.append(
                f"[Chunk {chunk['chunk_uid']} | page ~{chunk['page_est']}]\n{chunk['text']}"
            )
        context = "\n\n---\n\n".join(context_parts)

        print(f"  [{count}/{total}] {obs_id} ({segment}) ...", end=" ", flush=True)
        val, raw = extract_value(obs, variable, context)
        print(f"-> {val!r}")

        results.append({
            "company": COMPANY_NAME, "variable": var_name,
            "obs_id": obs_id, "segment": segment,
            "year": obs.get("year", FISCAL_YEAR),
            "extracted_value": val, "num_chunks_used": num_chunks,
            "raw_llm_response": raw,
        })
        time.sleep(2)

    # Creating extraction results as Spark DataFrame
    df_results_spark = spark.createDataFrame(pd.DataFrame(results))

    # Extraction summary
    df_results_spark.createOrReplaceTempView("extractions")
    print("\n  Spark SQL: Extraction Summary:")
    spark.sql("""
        SELECT variable,
               COUNT(*) as total_observations,
               SUM(CASE WHEN extracted_value IS NOT NULL THEN 1 ELSE 0 END) as non_null,
               SUM(CASE WHEN extracted_value IS NULL THEN 1 ELSE 0 END) as null_count,
               ROUND(AVG(num_chunks_used), 1) as avg_chunks
        FROM extractions
        GROUP BY variable
        ORDER BY variable
    """).show(truncate=False)

    # Saving results
    df_ext_pd = df_results_spark.toPandas()
    df_ext_pd.to_csv(EXTRACTED_PATH, index=False)
    print(f"\n  Saved {len(df_ext_pd)} extractions -> {EXTRACTED_PATH}\n")
    print(df_ext_pd[["obs_id", "variable", "segment", "extracted_value"]].to_string(index=False))
    return spark

if __name__ == "__main__":
    spark = run()
    if spark:
        spark.stop()