"""
Step 4: Retrieve top-k relevant chunks per observation using PySpark.

"""

import sys, json
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import (
    EMBEDDINGS_DIR, CHUNKS_DIR, RESULTS_DIR,
    VARIABLES, OBSERVATIONS, TOP_K_CHUNKS,
    EMBEDDING_BACKEND, LOCAL_EMBED_MODEL,
    OPENAI_EMBED_MODEL, OPENAI_API_KEY,
    COMPANY_NAME, FISCAL_YEAR,
    SPARK_APP_NAME, SPARK_MASTER,
)

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, FloatType,
    ArrayType, DoubleType,
)
from pyspark.sql.window import Window

RETRIEVED_PATH = RESULTS_DIR / "retrieved_chunks.csv"

# Lexical boost terms per variable
LEXICAL_TERMS = {
    "net_premiums_written": [
        "net premiums written", "underwriting results",
        "business segment operations",
        "Consolidated Results of Operations", "international commercial", "global personal",
    ],
    "underwriting_income": [
        "Underwriting income", "combined ratio",
        "business segment operations", "years ended december 31",
        "international commercial", "global personal", "underwriting income loss",
    ],
    "regulatory_jurisdiction": [
        "regulatory regimes", "financial services agency",
        "insurance regulator", "prudential supervisor", "monetary authority",
        "insurance operations", "lead state regulator",
    ],
}


# Embedding query texts
def embed_texts(texts):
    if EMBEDDING_BACKEND == "openai":
        import openai
        client = openai.OpenAI(api_key=OPENAI_API_KEY)
        all_vecs = []
        for i in range(0, len(texts), 512):
            resp = client.embeddings.create(
                input=texts[i:i+512], model=OPENAI_EMBED_MODEL
            )
            all_vecs.extend([item.embedding for item in resp.data])
        return np.array(all_vecs, dtype=np.float32)
    else:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(LOCAL_EMBED_MODEL)
        return model.encode(texts, batch_size=64, show_progress_bar=False)


# Cosine similarity
def cosine_sim(q_vec, matrix):
    q = q_vec / (np.linalg.norm(q_vec) + 1e-9)
    norms = np.linalg.norm(matrix, axis=1, keepdims=True) + 1e-9
    return (matrix / norms) @ q


# Lexical boost for chunks containing key terms
def lexical_boost(texts, var_name, obs=None):
    terms = LEXICAL_TERMS.get(var_name, [])
    if obs:
        segment = obs.get("segment", obs.get("jurisdiction", ""))
        if segment:
            terms = terms + [segment.lower()]
        year = obs.get("year", "")
        if year:
            terms = terms + [str(year)]
    boosts = []
    for text in texts:
        text_l = str(text).lower()
        hits = sum(1 for term in terms if term in text_l)
        boosts.append(min(0.20, hits * 0.03))
    return np.array(boosts, dtype=np.float32)


# Main Function
def run(spark=None):
    """Run retrieval. Accepts an existing SparkSession for pipeline reuse."""
    print(f"\n{'='*60}")
    print(f"  Step 4: Retrieval (PySpark, TOP_K={TOP_K_CHUNKS})")
    print(f"  Company: {COMPANY_NAME} | Filing: {FISCAL_YEAR} 10-K")
    print(f"  Embedding: {EMBEDDING_BACKEND}")
    print(f"{'='*60}\n")

    # Create or reuse SparkSession
    if spark is None:
        spark = (SparkSession.builder
                 .appName(SPARK_APP_NAME).master(SPARK_MASTER)
                 .config("spark.driver.memory", "4g").getOrCreate())
        spark.sparkContext.setLogLevel("WARN")

    # Loading chunks and embeddings as Spark DataFrames
    chunks_path = CHUNKS_DIR / "chunks.csv"
    embed_path = EMBEDDINGS_DIR / "embeddings.csv"
    if not chunks_path.exists():
        sys.exit(f"Chunks not found. Run Step 3 first.")
    if not embed_path.exists():
        sys.exit(f"Embeddings not found. Run Step 3 first.")

    df_chunks_spark = spark.read.csv(str(chunks_path), header=True, inferSchema=True)
    df_embed_spark = spark.read.csv(str(embed_path), header=True, inferSchema=True)

    print(f"  Loaded {df_chunks_spark.count():,} chunks (Spark DataFrame)")
    print(f"  Loaded {df_embed_spark.count():,} embeddings (Spark DataFrame)")

    # Joining chunks with embeddings on uid
    df_merged_spark = df_chunks_spark.join(
        df_embed_spark.select("uid", "embedding_json"),
        on="uid",
        how="inner"
    )

    print(f"  Joined DataFrame: {df_merged_spark.count():,} rows")

    # Spark SQL: Pre-retrieval analysis
    df_merged_spark.createOrReplaceTempView("chunks_with_embeddings")

    print("\n  Spark SQL: Chunk distribution summary:")
    spark.sql("""
        SELECT company, year,
               COUNT(*) as total_chunks,
               MIN(page_est) as first_page,
               MAX(page_est) as last_page,
               COUNT(DISTINCT page_est) as unique_pages
        FROM chunks_with_embeddings
        GROUP BY company, year
    """).show(truncate=False)

    # Collecting to Pandas for similarity computation
    df = df_merged_spark.toPandas()
    df["embedding"] = df["embedding_json"].apply(json.loads)
    matrix = np.array(df["embedding"].tolist(), dtype=np.float32)
    print(f"  Embedding Matrix: {matrix.shape[0]:,} chunks x {matrix.shape[1]} dims\n")

    # RETRIEVAL: Compute similarity scores per observation
    all_retrieved = []

    for var in VARIABLES:
        var_name = var["name"]
        print(f"  Variable: {var['display']} ({var_name})")
        obs_list = OBSERVATIONS.get(var_name, [])
        for obs in obs_list:
            obs_id = obs["obs_id"]
            segment = obs.get("segment", obs.get("jurisdiction", ""))
            year = obs.get("year", "")

            # Building observation-specific queries
            obs_queries = []
            for base_query in var["search_queries"]:
                obs_queries.append(f"{base_query} {segment} {year}".strip())
            obs_query_vecs = embed_texts(obs_queries)

            # Lexical boost
            boost = lexical_boost(df["text"].tolist(), var_name, obs)

            # Best score across all queries
            best_scores = np.zeros(len(df), dtype=np.float32)
            best_query = [""] * len(df)
            for query_text, q_vec in zip(obs_queries, obs_query_vecs):
                semantic = cosine_sim(q_vec, matrix)
                combined = semantic + boost
                for idx in range(len(df)):
                    if combined[idx] > best_scores[idx]:
                        best_scores[idx] = combined[idx]
                        best_query[idx] = query_text

            top_idx = np.argsort(best_scores)[::-1][:TOP_K_CHUNKS]
            for rank, idx in enumerate(top_idx):
                row = df.iloc[idx]
                all_retrieved.append({
                    "company":    row["company"],
                    "variable":   var_name,
                    "obs_id":     obs_id,
                    "chunk_uid":  row["uid"],
                    "page_est":   int(row["page_est"]),
                    "score":      float(best_scores[idx]),
                    "best_query": best_query[idx],
                    "rank":       rank + 1,
                    "text":       row["text"],
                })
            top_pages = [int(df.iloc[i]["page_est"]) for i in top_idx]
            print(f"    {obs_id} ({segment}) -> pages {top_pages}")
        print()

    # Window Functions: Rank retrieved chunks
    # Creating Spark DataFrame from retrieved results
    df_retrieved_pd = pd.DataFrame(all_retrieved)
    df_retrieved_spark = spark.createDataFrame(df_retrieved_pd)

    # Partition by variable + obs_id, order by score descending
    window_spec = Window.partitionBy("variable", "obs_id").orderBy(F.col("score").desc())

    # Applying row_number to rank chunks within each observation
    df_ranked = df_retrieved_spark.withColumn("spark_rank", F.row_number().over(window_spec))

    # Filtering to top-k per observation using window function result
    df_top_k = df_ranked.filter(F.col("spark_rank") <= TOP_K_CHUNKS)

    # Drop duplicates using Spark
    df_top_k = df_top_k.dropDuplicates(["variable", "obs_id", "chunk_uid"])

    # Retrieval summary statistics
    df_top_k.createOrReplaceTempView("retrieved_chunks")

    print("  Spark SQL: Retrieval Summary per Variable:")
    spark.sql("""
        SELECT variable,
               COUNT(*) as total_retrieved,
               COUNT(DISTINCT obs_id) as observations,
               ROUND(AVG(score), 4) as avg_score,
               ROUND(MIN(score), 4) as min_score,
               ROUND(MAX(score), 4) as max_score,
               COUNT(DISTINCT page_est) as unique_pages
        FROM retrieved_chunks
        GROUP BY variable
        ORDER BY variable
    """).show(truncate=False)

    # Aggregations: Score distribution per observation
    print("  Spark Aggregation: Score distribution per observation:")
    df_top_k.groupBy("variable", "obs_id").agg(
        F.round(F.avg("score"), 4).alias("avg_score"),
        F.round(F.min("score"), 4).alias("min_score"),
        F.round(F.max("score"), 4).alias("max_score"),
        F.count("chunk_uid").alias("chunks_retrieved"),
    ).orderBy("variable", "obs_id").show(20, truncate=False)

    # Saving retrieved chunks
    pdf_final = df_top_k.select(
        "company", "variable", "obs_id", "chunk_uid", "page_est",
        "score", "best_query", "rank", "text"
    ).toPandas()
    pdf_final = pdf_final.sort_values("score", ascending=False).reset_index(drop=True)
    pdf_final.to_csv(RETRIEVED_PATH, index=False)
    print(f"  Saved {len(pdf_final):,} retrieved chunks -> {RETRIEVED_PATH}")
    return spark


if __name__ == "__main__":
    spark = run()
    if spark:
        spark.stop()